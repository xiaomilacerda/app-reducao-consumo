'use client';

import React, { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { createBrowserClient } from '@supabase/ssr';
import { ArrowLeft, BarChart2, Clock, TrendingUp, List } from 'lucide-react';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, BarChart, Bar } from 'recharts';

function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}

function formatDateShort(d: string) {
  try {
    return new Date(d).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
  } catch { return d; }
}

export default function SosAdminAnalytics() {
  const supabase = createClient();
  const [loading, setLoading] = useState(true);

  const [aggregates, setAggregates] = useState<any[]>([]);
  const [daily, setDaily] = useState<any[]>([]);
  const [recentUsage, setRecentUsage] = useState<any[]>([]);

  const [query, setQuery] = useState('');
  const [topN, setTopN] = useState(10);

  useEffect(() => {
    let mounted = true;
    async function load() {
      setLoading(true);
      try {
        const { data: agg } = await supabase.from('sos_usage_aggregates').select('*').order('total_seconds', { ascending: false }).limit(200);
        const { data: d } = await supabase.from('sos_usage_daily').select('*').order('day_utc', { ascending: true }).limit(1000);
        const { data: r } = await supabase.from('sos_usage').select('id, user_id, sos_id, duration_seconds, metadata, created_at').order('created_at', { ascending: false }).limit(50);

        if (!mounted) return;
        setAggregates(agg ?? []);
        setDaily(d ?? []);
        setRecentUsage(r ?? []);
      } catch (err) {
        console.error('Erro carregando analytics SOS', err);
      } finally {
        if (mounted) setLoading(false);
      }
    }
    load();
    return () => { mounted = false; };
  }, [supabase]);

  const filteredAggregates = useMemo(() => {
    const q = query.trim().toLowerCase();
    return (aggregates ?? []).filter(a => !q || (a.title ?? '').toLowerCase().includes(q)).slice(0, topN);
  }, [aggregates, query, topN]);

  // prepare line chart data: sum total_minutes per day across tools (for last 30 days)
  const lineData = useMemo(() => {
    if (!daily || !daily.length) return [];
    // create map date => minutes sum
    const map: Record<string, number> = {};
    for (const r of daily) {
      const k = String(r.day_utc);
      map[k] = (map[k] ?? 0) + Number(r.total_minutes || 0);
    }
    const keys = Object.keys(map).sort();
    return keys.map(k => ({ date: formatDateShort(k), minutes: Math.round(map[k] * 100) / 100 }));
  }, [daily]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-gray-50 to-pink-50">
        <div className="animate-spin w-12 h-12 border-4 border-purple-600 border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
      <header className="sticky top-0 bg-white/80 backdrop-blur-sm z-40">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center gap-3">
          <Link href="/" className="p-2 rounded hover:bg-gray-100"><ArrowLeft className="w-6 h-6 text-gray-600" /></Link>
          <BarChart2 className="w-8 h-8 text-purple-500" />
          <h1 className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-pink-600">Admin — Analytics SOS</h1>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8 space-y-6">
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-white p-4 rounded-2xl shadow">
            <h3 className="text-sm font-semibold text-gray-600">Top ferramentas (por minutos)</h3>
            <div className="mt-3 space-y-2">
              {filteredAggregates.map((a, idx) => (
                <div key={a.sos_id} className="flex items-center justify-between">
                  <div>
                    <div className="text-sm font-medium">{a.title}</div>
                    <div className="text-xs text-gray-500">{a.category ?? '—'}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm font-semibold">{a.total_minutes} min</div>
                    <div className="text-xs text-gray-400">{a.sessions} sessões</div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 flex items-center gap-2">
              <input placeholder="Buscar..." value={query} onChange={(e)=>setQuery(e.target.value)} className="p-2 border rounded w-full" />
              <select value={String(topN)} onChange={(e)=>setTopN(Number(e.target.value))} className="p-2 border rounded">
                <option value="5">Top 5</option>
                <option value="10">Top 10</option>
                <option value="20">Top 20</option>
              </select>
            </div>
          </div>

          <div className="bg-white p-4 rounded-2xl shadow">
            <h3 className="text-sm font-semibold text-gray-600">Evolução diária (minutos)</h3>
            <div style={{ width: '100%', height: 220 }}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={lineData}>
                  <XAxis dataKey="date" stroke="#aaa" />
                  <YAxis stroke="#aaa" />
                  <Tooltip />
                  <Line dataKey="minutes" type="monotone" stroke="#d946ef" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>

            <div className="mt-3 text-sm text-gray-600">Últimos dias: {lineData.length}</div>
          </div>

          <div className="bg-white p-4 rounded-2xl shadow">
            <h3 className="text-sm font-semibold text-gray-600">Resumo rápido</h3>
            <div className="mt-3 space-y-2">
              <div className="flex items-center justify-between"><div className="text-xs text-gray-500">Ferramentas catalogadas</div><div className="font-medium">{aggregates.length}</div></div>
              <div className="flex items-center justify-between"><div className="text-xs text-gray-500">Registros recentes</div><div className="font-medium">{recentUsage.length}</div></div>
            </div>

            <div className="mt-4">
              <Link href="/admin" className="px-3 py-2 bg-white border rounded">Voltar ao admin</Link>
            </div>
          </div>
        </section>

        <section className="bg-white p-4 rounded-2xl shadow">
          <h3 className="text-sm font-semibold text-gray-600">Registros recentes</h3>
          <div className="mt-3 grid gap-2">
            {recentUsage.map(r => (
              <div key={r.id} className="p-3 border rounded flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium">Tool ID: {r.sos_id}</div>
                  <div className="text-xs text-gray-500">Usuário: {r.user_id}</div>
                </div>
                <div className="text-right">
                  <div className="text-sm">{Math.round((r.duration_seconds||0)/60)} min</div>
                  <div className="text-xs text-gray-400">{new Date(r.created_at).toLocaleString()}</div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
