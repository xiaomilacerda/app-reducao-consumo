'use client';

import React, { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { createBrowserClient } from '@supabase/ssr';
import { ArrowLeft, Plus, Trash2, Edit3, Database } from 'lucide-react';
import AdminCsvImporter from '@/components/AdminCsvImporter';

function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}

type Mission = {
  id?: number;
  title: string;
  description?: string | null;
  type?: string | null;
  reward_xp?: number | null;
  reward_coins?: number | null;
  premium_only?: boolean | null;
  category?: string | null;
  difficulty?: string | null;
};

type SosTool = {
  id?: number;
  title: string;
  description?: string | null;
  duration_minutes?: number | null;
  audio_url?: string | null;
  thumbnail?: string | null;
  tags?: string[] | null;
  steps_json?: any;
  is_audio?: boolean | null;
  premium_only?: boolean | null;
};

export default function AdminPage() {
  const supabase = useMemo(createClient, []);
  const [checkingAdmin, setCheckingAdmin] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  // Missions
  const [missions, setMissions] = useState<Mission[]>([]);
  const [missionsQuery, setMissionsQuery] = useState('');
  const [missionModalOpen, setMissionModalOpen] = useState(false);
  const [editingMission, setEditingMission] = useState<Mission | null>(null);
  const [processingMission, setProcessingMission] = useState(false);

  // SOS tools
  const [tools, setTools] = useState<SosTool[]>([]);
  const [toolsQuery, setToolsQuery] = useState('');
  const [toolModalOpen, setToolModalOpen] = useState(false);
  const [editingTool, setEditingTool] = useState<SosTool | null>(null);
  const [processingTool, setProcessingTool] = useState(false);

  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // check admin user
  useEffect(() => {
    let mounted = true;
    async function check() {
      setCheckingAdmin(true);
      try {
        const { data: authData, error: authErr } = await supabase.auth.getUser();
        if (authErr) console.warn('auth.getUser error', authErr);
        const uid = authData?.user?.id ?? null;
        if (!mounted) return;
        setUserId(uid);
        if (!uid) {
          setIsAdmin(false);
          setCheckingAdmin(false);
          return;
        }

        // is the user present in admin_users?
        const { data: admins, error } = await supabase.from('admin_users').select('id').eq('id', uid).limit(1);
        if (error) {
          console.warn('admin_users check error', error);
          // if table missing, fall back to profiles.is_admin
          const { data: p, error: pErr } = await supabase.from('profiles').select('is_admin').eq('id', uid).limit(1).maybeSingle();
          if (pErr) console.warn('profiles.is_admin check err', pErr);
          const adm = !!p?.is_admin;
          setIsAdmin(adm);
        } else {
          setIsAdmin(Array.isArray(admins) && admins.length > 0);
        }
      } catch (err) {
        console.error('admin check error', err);
        setIsAdmin(false);
      } finally {
        if (mounted) { setCheckingAdmin(false); setLoading(false); }
      }
    }
    check();
    return () => { mounted = false; };
  }, [supabase]);

  // load missions & tools
  useEffect(() => {
    let mounted = true;
    async function load() {
      setLoading(true);
      try {
        const [mRes, sRes] = await Promise.all([
          supabase.from('missions').select('*').order('created_at', { ascending: true }),
          supabase.from('sos_tools').select('*').order('created_at', { ascending: true }),
        ]);
        if (!mounted) return;
        if (mRes.error) {
          console.warn('missions load error', mRes.error);
          setMissions([]);
        } else setMissions(mRes.data ?? []);
        if (sRes.error) {
          console.warn('sos_tools load error', sRes.error);
          setTools([]);
        } else setTools(sRes.data ?? []);
      } catch (err) {
        console.error('load admin data error', err);
        setMissions([]); setTools([]);
      } finally {
        if (mounted) setLoading(false);
      }
    }
    if (!checkingAdmin) load();
    return () => { mounted = false; };
  }, [supabase, checkingAdmin, missionModalOpen, toolModalOpen]);

  // helpers
  function clearMessages() { setErrorMsg(null); setSuccessMsg(null); }

  /* ---------- Missions CRUD ---------- */
  function openNewMission() {
    setEditingMission({ title: '', description: '', type: 'daily', reward_xp: 0, reward_coins: 0, premium_only: false, category: '', difficulty: '' });
    setMissionModalOpen(true);
  }
  function openEditMission(m: Mission) {
    setEditingMission({ ...m });
    setMissionModalOpen(true);
  }

  async function saveMission() {
    if (!editingMission) return;
    setProcessingMission(true); clearMessages();
    try {
      if (editingMission.id && Number(editingMission.id) > 0) {
        // update
        const { error } = await supabase.from('missions').update({
          title: editingMission.title,
          description: editingMission.description,
          type: editingMission.type,
          reward_xp: editingMission.reward_xp ?? 0,
          reward_coins: editingMission.reward_coins ?? 0,
          premium_only: editingMission.premium_only ?? false,
          category: editingMission.category,
          difficulty: editingMission.difficulty,
        }).eq('id', editingMission.id);
        if (error) throw error;
        setSuccessMsg('Missão atualizada com sucesso.');
      } else {
        // create
        const { data, error } = await supabase.from('missions').insert([{
          title: editingMission.title,
          description: editingMission.description,
          type: editingMission.type,
          reward_xp: editingMission.reward_xp ?? 0,
          reward_coins: editingMission.reward_coins ?? 0,
          premium_only: editingMission.premium_only ?? false,
          category: editingMission.category,
          difficulty: editingMission.difficulty,
        }]).select().maybeSingle();
        if (error) throw error;
        setSuccessMsg('Missão criada com sucesso.');
        // push new row locally
        setMissions(prev => data ? [...prev, data as Mission] : prev);
      }
      setMissionModalOpen(false);
    } catch (err:any) {
      console.error('saveMission error', err);
      setErrorMsg(err?.message ?? 'Erro ao salvar missão.');
    } finally {
      setProcessingMission(false);
    }
  }

  async function deleteMission(id?: number) {
    if (!id) return;
    if (!confirm('Confirma excluir esta missão? A ação é irreversível.')) return;
    try {
      const { error } = await supabase.from('missions').delete().eq('id', id);
      if (error) throw error;
      setMissions(prev => prev.filter(m => m.id !== id));
      setSuccessMsg('Missão excluída.');
    } catch (err:any) {
      console.error('deleteMission error', err);
      setErrorMsg(err?.message ?? 'Erro ao excluir missão.');
    }
  }

  /* ---------- SOS Tools CRUD ---------- */
  function openNewTool() {
    setEditingTool({ title: '', description: '', duration_minutes: 1, audio_url: '', thumbnail: '', tags: [], steps_json: null, is_audio: false, premium_only: false });
    setToolModalOpen(true);
  }
  function openEditTool(t: SosTool) {
    setEditingTool({ ...t });
    setToolModalOpen(true);
  }

  async function saveTool() {
    if (!editingTool) return;
    setProcessingTool(true); clearMessages();
    try {
      if (editingTool.id && Number(editingTool.id) > 0) {
        const { error } = await supabase.from('sos_tools').update({
          title: editingTool.title,
          description: editingTool.description,
          duration_minutes: editingTool.duration_minutes,
          audio_url: editingTool.audio_url,
          thumbnail: editingTool.thumbnail,
          tags: editingTool.tags,
          steps_json: editingTool.steps_json,
          is_audio: editingTool.is_audio,
          premium_only: editingTool.premium_only,
        }).eq('id', editingTool.id);
        if (error) throw error;
        setSuccessMsg('Ferramenta SOS atualizada.');
      } else {
        const { data, error } = await supabase.from('sos_tools').insert([{
          title: editingTool.title,
          description: editingTool.description,
          duration_minutes: editingTool.duration_minutes,
          audio_url: editingTool.audio_url,
          thumbnail: editingTool.thumbnail,
          tags: editingTool.tags,
          steps_json: editingTool.steps_json,
          is_audio: editingTool.is_audio,
          premium_only: editingTool.premium_only,
        }]).select().maybeSingle();
        if (error) throw error;
        if (data) setTools(prev => [...prev, data as SosTool]);
        setSuccessMsg('Ferramenta SOS criada.');
      }
      setToolModalOpen(false);
    } catch (err:any) {
      console.error('saveTool error', err);
      setErrorMsg(err?.message ?? 'Erro ao salvar ferramenta SOS.');
    } finally {
      setProcessingTool(false);
    }
  }

  async function deleteTool(id?: number) {
    if (!id) return;
    if (!confirm('Confirma excluir esta ferramenta SOS?')) return;
    try {
      const { error } = await supabase.from('sos_tools').delete().eq('id', id);
      if (error) throw error;
      setTools(prev => prev.filter(t => t.id !== id));
      setSuccessMsg('Ferramenta excluída.');
    } catch (err:any) {
      console.error('deleteTool error', err);
      setErrorMsg(err?.message ?? 'Erro ao excluir ferramenta.');
    }
  }

  /* ---------- Render ---------- */
  if (checkingAdmin || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-purple-500 border-t-transparent"></div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 flex items-center justify-center p-4">
        <div className="max-w-xl w-full bg-white p-6 rounded-2xl shadow text-center">
          <Database className="mx-auto mb-3 w-8 h-8 text-gray-600" />
          <h2 className="text-lg font-semibold">Painel administrativo</h2>
          <p className="mt-2 text-sm text-gray-600">Você não tem permissão administrativa. Para acessar, adicione seu ID na tabela <code>admin_users</code> ou configure <code>profiles.is_admin</code>.</p>
          <div className="mt-4">
            <Link href="/" className="px-4 py-2 rounded bg-purple-600 text-white">Voltar</Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 pb-12">
      <header className="sticky top-0 bg-white/80 backdrop-blur-sm p-4 shadow z-40">
        <div className="max-w-7xl mx-auto flex items-center gap-4">
          <Link href="/" className="p-2 rounded hover:bg-gray-100"><ArrowLeft className="w-6 h-6 text-gray-600" /></Link>
          <h1 className="text-xl font-bold">Painel Administrativo</h1>
          <div className="ml-auto flex items-center gap-2">
            <button onClick={() => { setMissionsQuery(''); setToolsQuery(''); }} className="px-3 py-1 rounded border">Reset filtros</button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8 grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Missions */}
        <section className="bg-white p-4 rounded-2xl shadow">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">Missions</h2>
            <div className="flex items-center gap-2">
              <input placeholder="Buscar missões..." value={missionsQuery} onChange={(e) => setMissionsQuery(e.target.value)} className="px-3 py-2 rounded border text-sm" />
              <button onClick={openNewMission} className="px-3 py-2 rounded bg-purple-600 text-white inline-flex items-center gap-2"><Plus className="w-4 h-4" />Nova</button>
            </div>
          </div>

          {/* CSV Importer integrado aqui */}
          <div className="mb-4">
            <AdminCsvImporter defaultTable="missions" />
          </div>

          <div className="space-y-3 max-h-[60vh] overflow-auto pr-2">
            {missions.filter(m => !missionsQuery || (m.title + ' ' + (m.description ?? '')).toLowerCase().includes(missionsQuery.toLowerCase())).map(m => (
              <div key={String(m.id)} className="p-3 border rounded-lg flex items-start justify-between">
                <div>
                  <div className="font-semibold">{m.title}</div>
                  <div className="text-sm text-gray-600">{m.description}</div>
                  <div className="text-xs text-gray-500 mt-1">Tipo: {m.type ?? '—'} • XP: {m.reward_xp ?? 0} • Coins: {m.reward_coins ?? 0} • Premium: {m.premium_only ? 'Sim' : 'Não'}</div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <div className="flex gap-2">
                    <button title="Editar" onClick={() => openEditMission(m)} className="p-2 rounded border text-sm inline-flex items-center gap-2"><Edit3 className="w-4 h-4" /></button>
                    <button title="Excluir" onClick={() => deleteMission(m.id)} className="p-2 rounded border text-sm inline-flex items-center gap-2 text-red-600"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </div>
              </div>
            ))}
            {missions.length === 0 && <div className="text-sm text-gray-500 p-3">Nenhuma missão encontrada.</div>}
          </div>
        </section>

        {/* Right: SOS Tools */}
        <section className="bg-white p-4 rounded-2xl shadow">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">SOS Tools</h2>
            <div className="flex items-center gap-2">
              <input placeholder="Buscar ferramentas..." value={toolsQuery} onChange={(e) => setToolsQuery(e.target.value)} className="px-3 py-2 rounded border text-sm" />
              <button onClick={openNewTool} className="px-3 py-2 rounded bg-purple-600 text-white inline-flex items-center gap-2"><Plus className="w-4 h-4" />Nova</button>
            </div>
          </div>

          <div className="space-y-3 max-h-[60vh] overflow-auto pr-2">
            {tools.filter(t => !toolsQuery || (t.title + ' ' + (t.description ?? '')).toLowerCase().includes(toolsQuery.toLowerCase())).map(t => (
              <div key={String(t.id)} className="p-3 border rounded-lg flex items-start justify-between">
                <div>
                  <div className="font-semibold">{t.title}</div>
                  <div className="text-sm text-gray-600">{t.description}</div>
                  <div className="text-xs text-gray-500 mt-1">Dur: {t.duration_minutes ?? '—'}m • Tags: {(t.tags || []).join(', ')}</div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <div className="flex gap-2">
                    <button title="Editar" onClick={() => openEditTool(t)} className="p-2 rounded border text-sm inline-flex items-center gap-2"><Edit3 className="w-4 h-4" /></button>
                    <button title="Excluir" onClick={() => deleteTool(t.id)} className="p-2 rounded border text-sm inline-flex items-center gap-2 text-red-600"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </div>
              </div>
            ))}
            {tools.length === 0 && <div className="text-sm text-gray-500 p-3">Nenhuma ferramenta encontrada.</div>}
          </div>
        </section>

        {/* messages */}
        <div className="lg:col-span-2">
          {errorMsg && <div className="bg-red-50 text-red-700 p-3 rounded mb-3">{errorMsg}</div>}
          {successMsg && <div className="bg-green-50 text-green-700 p-3 rounded mb-3">{successMsg}</div>}
        </div>
      </main>

      {/* Mission Modal */}
      {missionModalOpen && editingMission && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/40" onClick={() => setMissionModalOpen(false)} />
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-2xl p-6">
            <h3 className="font-semibold mb-2">{editingMission.id ? 'Editar Missão' : 'Nova Missão'}</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <input placeholder="Título" value={editingMission.title} onChange={(e) => setEditingMission(s => s ? ({ ...s, title: e.target.value }) : s)} className="px-3 py-2 border rounded" />
              <select value={editingMission.type ?? 'daily'} onChange={(e) => setEditingMission(s => s ? ({ ...s, type: e.target.value }) : s)} className="px-3 py-2 border rounded">
                <option value="daily">daily</option>
                <option value="weekly">weekly</option>
                <option value="oneoff">oneoff</option>
              </select>

              <textarea placeholder="Descrição" value={editingMission.description ?? ''} onChange={(e) => setEditingMission(s => s ? ({ ...s, description: e.target.value }) : s)} className="col-span-1 md:col-span-2 px-3 py-2 border rounded" />

              <input type="number" placeholder="XP" value={editingMission.reward_xp ?? 0} onChange={(e) => setEditingMission(s => s ? ({ ...s, reward_xp: Number(e.target.value) }) : s)} className="px-3 py-2 border rounded" />
              <input type="number" placeholder="Coins" value={editingMission.reward_coins ?? 0} onChange={(e) => setEditingMission(s => s ? ({ ...s, reward_coins: Number(e.target.value) }) : s)} className="px-3 py-2 border rounded" />

              <input placeholder="Categoria" value={editingMission.category ?? ''} onChange={(e) => setEditingMission(s => s ? ({ ...s, category: e.target.value }) : s)} className="px-3 py-2 border rounded" />
              <input placeholder="Dificuldade" value={editingMission.difficulty ?? ''} onChange={(e) => setEditingMission(s => s ? ({ ...s, difficulty: e.target.value }) : s)} className="px-3 py-2 border rounded" />

              <label className="flex items-center gap-2">
                <input type="checkbox" checked={!!editingMission.premium_only} onChange={(e) => setEditingMission(s => s ? ({ ...s, premium_only: e.target.checked }) : s)} />
                <span className="text-sm">Premium only</span>
              </label>
            </div>

            <div className="mt-4 flex justify-end gap-2">
              <button onClick={() => setMissionModalOpen(false)} className="px-4 py-2 rounded border">Cancelar</button>
              <button onClick={saveMission} disabled={processingMission} className="px-4 py-2 rounded bg-purple-600 text-white">{processingMission ? 'Salvando...' : 'Salvar'}</button>
            </div>
          </div>
        </div>
      )}

      {/* Tool Modal */}
      {toolModalOpen && editingTool && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/40" onClick={() => setToolModalOpen(false)} />
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-2xl p-6">
            <h3 className="font-semibold mb-2">{editingTool.id ? 'Editar Ferramenta SOS' : 'Nova Ferramenta SOS'}</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <input placeholder="Título" value={editingTool.title ?? ''} onChange={(e) => setEditingTool(s => s ? ({ ...s, title: e.target.value }) : s)} className="px-3 py-2 border rounded" />
              <input placeholder="Thumbnail URL" value={editingTool.thumbnail ?? ''} onChange={(e) => setEditingTool(s => s ? ({ ...s, thumbnail: e.target.value }) : s)} className="px-3 py-2 border rounded" />

              <textarea placeholder="Descrição" value={editingTool.description ?? ''} onChange={(e) => setEditingTool(s => s ? ({ ...s, description: e.target.value }) : s)} className="col-span-1 md:col-span-2 px-3 py-2 border rounded" />

              <input type="number" placeholder="Duration minutes" value={editingTool.duration_minutes ?? 1} onChange={(e) => setEditingTool(s => s ? ({ ...s, duration_minutes: Number(e.target.value) }) : s)} className="px-3 py-2 border rounded" />
              <input placeholder="Audio URL" value={editingTool.audio_url ?? ''} onChange={(e) => setEditingTool(s => s ? ({ ...s, audio_url: e.target.value }) : s)} className="px-3 py-2 border rounded" />

              <input placeholder="Tags (comma separated)" value={(editingTool.tags || []).join?.(',') ?? ''} onChange={(e) => setEditingTool(s => s ? ({ ...s, tags: e.target.value.split(',').map((t) => t.trim()).filter(Boolean) }) : s)} className="px-3 py-2 border rounded" />

              <textarea placeholder="steps_json (JSON)" value={editingTool.steps_json ? JSON.stringify(editingTool.steps_json, null, 2) : ''} onChange={(e) => {
                try {
                  const parsed = e.target.value ? JSON.parse(e.target.value) : null;
                  setEditingTool(s => s ? ({ ...s, steps_json: parsed }) : s);
                } catch (err) {
                  // keep raw until valid
                  setEditingTool(s => s ? ({ ...s, steps_json: e.target.value }) : s);
                }
              }} className="col-span-1 md:col-span-2 px-3 py-2 border rounded" />

              <label className="flex items-center gap-2">
                <input type="checkbox" checked={!!editingTool.is_audio} onChange={(e) => setEditingTool(s => s ? ({ ...s, is_audio: e.target.checked }) : s)} />
                <span className="text-sm">Is audio</span>
              </label>

              <label className="flex items-center gap-2">
                <input type="checkbox" checked={!!editingTool.premium_only} onChange={(e) => setEditingTool(s => s ? ({ ...s, premium_only: e.target.checked }) : s)} />
                <span className="text-sm">Premium only</span>
              </label>
            </div>

            <div className="mt-4 flex justify-end gap-2">
              <button onClick={() => setToolModalOpen(false)} className="px-4 py-2 rounded border">Cancelar</button>
              <button onClick={saveTool} disabled={processingTool} className="px-4 py-2 rounded bg-purple-600 text-white">{processingTool ? 'Salvando...' : 'Salvar'}</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
