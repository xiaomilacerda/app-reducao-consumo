'use client';

import React, { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { createBrowserClient } from '@supabase/ssr';
import { ArrowLeft, User, Search, Edit3, Trash2, Plus, Key } from 'lucide-react';

function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}

type Profile = {
  id: string;
  display_name?: string | null;
  email?: string | null;
  is_admin?: boolean | null;
  timezone?: string | null;
  created_at?: string | null;
  avatar_url?: string | null;
  metadata?: any;
};

export default function AdminUsersPage() {
  const supabase = useMemo(createClient, []);
  const [checkingAdmin, setCheckingAdmin] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [query, setQuery] = useState('');
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 25;
  const [editing, setEditing] = useState<Profile | null>(null);
  const [processing, setProcessing] = useState(false);
  const [message, setMessage] = useState<{ type: 'success'|'error', text: string } | null>(null);

  // check admin user
  useEffect(() => {
    let mounted = true;
    async function check() {
      setCheckingAdmin(true);
      try {
        const { data: authData } = await supabase.auth.getUser();
        const uid = authData?.user?.id ?? null;
        if (!mounted) return;
        if (!uid) { setIsAdmin(false); setCheckingAdmin(false); return; }
        // check admin_users table first
        const { data: admins, error } = await supabase.from('admin_users').select('id').eq('id', uid).limit(1);
        if (!error && Array.isArray(admins) && admins.length > 0) {
          setIsAdmin(true);
        } else {
          // fallback to profiles.is_admin
          const { data: p, error: perr } = await supabase.from('profiles').select('is_admin').eq('id', uid).limit(1).maybeSingle();
          if (!perr && p?.is_admin) setIsAdmin(true);
          else setIsAdmin(false);
        }
      } catch (err) {
        console.error('admin check error', err);
        setIsAdmin(false);
      } finally {
        if (mounted) { setCheckingAdmin(false); }
      }
    }
    check();
    return () => { mounted = false; };
  }, [supabase]);

  // load profiles (paged)
  useEffect(() => {
    let mounted = true;
    async function load() {
      setLoading(true);
      try {
        // basic filter by query on display_name or email
        let q = supabase.from('profiles').select('*').order('created_at', { ascending: false }).limit(PAGE_SIZE).range((page-1)*PAGE_SIZE, page*PAGE_SIZE - 1);
        const { data, error } = await q;
        if (!mounted) return;
        if (error) {
          console.warn('profiles load err', error);
          setProfiles([]);
        } else {
          setProfiles(data ?? []);
        }
      } catch (err) {
        console.error('load profiles err', err);
        setProfiles([]);
      } finally {
        if (mounted) setLoading(false);
      }
    }
    if (!checkingAdmin) load();
    return () => { mounted = false; };
  }, [supabase, checkingAdmin, page]);

  // simple client-side filter when query changes
  const visible = profiles.filter(p => {
    if (!query) return true;
    const s = query.toLowerCase();
    if ((p.display_name ?? '').toLowerCase().includes(s)) return true;
    if ((p.email ?? '').toLowerCase().includes(s)) return true;
    if ((p.id ?? '').toLowerCase().includes(s)) return true;
    return false;
  });

  function clearMsgLater() {
    setTimeout(() => setMessage(null), 4500);
  }

  async function toggleAdmin(profile: Profile) {
    if (!profile?.id) return;
    setProcessing(true); setMessage(null);
    try {
      // flip profiles.is_admin
      const next = !profile.is_admin;
      const { error: upErr } = await supabase.from('profiles').update({ is_admin: next }).eq('id', profile.id);
      if (upErr) throw upErr;

      // ensure admin_users table mirrors state when possible
      if (next) {
        // insert into admin_users if not exists
        try {
          await supabase.from('admin_users').insert([{ id: profile.id }]);
        } catch (e) {
          // ignore
          console.warn('admin_users insert warning', e);
        }
      } else {
        try {
          await supabase.from('admin_users').delete().eq('id', profile.id);
        } catch (e) {
          console.warn('admin_users delete warning', e);
        }
      }

      setProfiles(prev => prev.map(p => p.id === profile.id ? { ...p, is_admin: next } : p));
      setMessage({ type: 'success', text: `Permissão admin de ${profile.display_name ?? profile.email ?? profile.id} atualizada.` });
      clearMsgLater();
    } catch (err:any) {
      console.error('toggleAdmin err', err);
      setMessage({ type: 'error', text: `Erro ao atualizar permissão: ${err?.message ?? String(err)}` });
    } finally {
      setProcessing(false);
    }
  }

  async function openEdit(profile: Profile) {
    setEditing({ ...profile });
    setMessage(null);
  }

  async function saveEdit() {
    if (!editing || !editing.id) return;
    setProcessing(true); setMessage(null);
    try {
      const payload: any = {
        display_name: editing.display_name ?? null,
        timezone: editing.timezone ?? null,
      };
      // can't change auth.email safely here — update profiles.email only if you store email there
      if (editing.email) payload.email = editing.email;

      const { error } = await supabase.from('profiles').update(payload).eq('id', editing.id);
      if (error) throw error;

      setProfiles(prev => prev.map(p => p.id === editing.id ? { ...p, ...payload } : p));
      setMessage({ type: 'success', text: 'Perfil atualizado.' });
      setEditing(null);
      clearMsgLater();
    } catch (err:any) {
      console.error('saveEdit err', err);
      setMessage({ type: 'error', text: `Erro ao salvar: ${err?.message ?? String(err)}` });
    } finally {
      setProcessing(false);
    }
  }

  async function sendPasswordReset(profile: Profile) {
    if (!profile?.email) {
      setMessage({ type: 'error', text: 'Usuário não possui e-mail para enviar link.' });
      clearMsgLater();
      return;
    }
    setProcessing(true); setMessage(null);
    try {
      const { data, error } = await supabase.auth.resetPasswordForEmail(profile.email);
      if (error) throw error;
      setMessage({ type: 'success', text: `E-mail de redefinição enviado para ${profile.email}.` });
      clearMsgLater();
    } catch (err:any) {
      console.error('reset pw err', err);
      setMessage({ type: 'error', text: `Erro ao enviar e-mail: ${err?.message ?? String(err)}` });
    } finally {
      setProcessing(false);
    }
  }

  async function removeProfile(profile: Profile) {
    if (!profile?.id) return;
    if (!confirm(`Excluir perfil ${profile.display_name ?? profile.email ?? profile.id}? Esta ação não remove o auth user.`)) return;
    setProcessing(true); setMessage(null);
    try {
      const { error } = await supabase.from('profiles').delete().eq('id', profile.id);
      if (error) throw error;
      setProfiles(prev => prev.filter(p => p.id !== profile.id));
      setMessage({ type: 'success', text: 'Perfil removido (dados de perfil).' });
      clearMsgLater();
    } catch (err:any) {
      console.error('removeProfile err', err);
      setMessage({ type: 'error', text: `Erro ao remover perfil: ${err?.message ?? String(err)}` });
    } finally {
      setProcessing(false);
    }
  }

  // quick reload of current page
  async function reloadPage() {
    setLoading(true);
    try {
      const { data, error } = await supabase.from('profiles').select('*').order('created_at', { ascending: false }).limit(PAGE_SIZE).range((page-1)*PAGE_SIZE, page*PAGE_SIZE - 1);
      if (error) { console.warn('reload err', error); setProfiles([]); }
      else setProfiles(data ?? []);
    } catch (err) {
      console.error('reload err', err); setProfiles([]);
    } finally {
      setLoading(false);
    }
  }

  if (checkingAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-12 h-12 rounded-full border-4 border-purple-500 border-t-transparent"></div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center p-4">
        <div className="max-w-xl w-full bg-white p-6 rounded-2xl shadow text-center">
          <User className="mx-auto mb-3 w-8 h-8 text-gray-600" />
          <h2 className="text-lg font-semibold">Acesso negado</h2>
          <p className="mt-2 text-sm text-gray-600">Você não tem permissão administrativa para gerenciar usuários.</p>
          <div className="mt-4"><Link href="/admin" className="px-4 py-2 rounded bg-purple-600 text-white">Voltar</Link></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 pb-16">
      <header className="sticky top-0 bg-white/90 backdrop-blur-sm p-4 shadow z-40">
        <div className="max-w-6xl mx-auto flex items-center gap-3">
          <Link href="/admin" className="p-2 rounded hover:bg-gray-100"><ArrowLeft className="w-6 h-6 text-gray-600" /></Link>
          <h1 className="text-xl font-bold">Usuários</h1>
          <div className="ml-auto flex items-center gap-2">
            <button onClick={() => reloadPage()} className="px-3 py-1 rounded border">Recarregar</button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8 space-y-6">
        {message && (
          <div className={`p-3 rounded ${message.type === 'success' ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'}`}>
            {message.text}
          </div>
        )}

        <div className="bg-white p-4 rounded-2xl shadow">
          <div className="flex items-center gap-3">
            <Search className="w-4 h-4 text-gray-400" />
            <input placeholder="Buscar por nome, email ou id..." value={query} onChange={(e)=>setQuery(e.target.value)} className="flex-1 px-3 py-2 border rounded" />
          </div>

          <div className="mt-4 space-y-3">
            {loading ? (
              <div className="py-6 text-center text-gray-500">Carregando...</div>
            ) : visible.length === 0 ? (
              <div className="py-6 text-center text-gray-500">Nenhum usuário encontrado nesta página.</div>
            ) : (
              visible.map(p => (
                <div key={p.id} className="p-3 border rounded-lg flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center text-xl select-none">
                      {p.display_name ? p.display_name.slice(0,1).toUpperCase() : (p.email ? p.email.slice(0,1).toUpperCase() : 'U')}
                    </div>
                    <div>
                      <div className="font-semibold">{p.display_name ?? '—'}</div>
                      <div className="text-sm text-gray-600">{p.email ?? '—'}</div>
                      <div className="text-xs text-gray-400 mt-1">ID: {p.id} • Criado em: {p.created_at ? new Date(p.created_at).toLocaleString() : '—'}</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button onClick={() => openEdit(p)} title="Editar" className="p-2 rounded border inline-flex items-center gap-2"><Edit3 className="w-4 h-4" /></button>
                    <button onClick={() => toggleAdmin(p)} disabled={processing} title={p.is_admin ? 'Remover admin' : 'Tornar admin'} className={`px-3 py-1 rounded border text-sm ${p.is_admin ? 'bg-yellow-50 text-yellow-700' : ''}`}>{p.is_admin ? 'Admin' : 'Make Admin'}</button>
                    <button onClick={() => sendPasswordReset(p)} title="Enviar link redefinição" className="p-2 rounded border inline-flex items-center gap-2"><Key className="w-4 h-4" /></button>
                    <button onClick={() => removeProfile(p)} title="Remover perfil" className="p-2 rounded border text-red-600 inline-flex items-center gap-2"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="mt-4 flex items-center justify-between text-sm text-gray-600">
            <div>
              Página {page}
            </div>
            <div className="flex items-center gap-2">
              <button onClick={() => setPage(p => Math.max(1, p-1))} className="px-2 py-1 rounded border">Anterior</button>
              <button onClick={() => setPage(p => p+1)} className="px-2 py-1 rounded border">Próxima</button>
            </div>
          </div>
        </div>

        {/* Edit modal */}
        {editing && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-black/40" onClick={() => setEditing(null)} />
            <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-2xl p-6">
              <h3 className="font-semibold mb-2">Editar usuário</h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <input placeholder="Nome" value={editing.display_name ?? ''} onChange={(e) => setEditing(s => s ? ({ ...s, display_name: e.target.value }) : s)} className="px-3 py-2 border rounded" />
                <input placeholder="E-mail" value={editing.email ?? ''} onChange={(e) => setEditing(s => s ? ({ ...s, email: e.target.value }) : s)} className="px-3 py-2 border rounded" />
                <input placeholder="Timezone (ex: America/Sao_Paulo)" value={editing.timezone ?? ''} onChange={(e) => setEditing(s => s ? ({ ...s, timezone: e.target.value }) : s)} className="px-3 py-2 border rounded col-span-1 md:col-span-2" />
                <label className="flex items-center gap-2">
                  <input type="checkbox" checked={!!editing.is_admin} onChange={(e) => setEditing(s => s ? ({ ...s, is_admin: e.target.checked }) : s)} />
                  <span className="text-sm">Is admin</span>
                </label>
              </div>

              <div className="mt-4 flex justify-end gap-2">
                <button onClick={() => setEditing(null)} className="px-4 py-2 rounded border">Cancelar</button>
                <button onClick={saveEdit} disabled={processing} className="px-4 py-2 rounded bg-purple-600 text-white">{processing ? 'Salvando...' : 'Salvar'}</button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
