'use client';

import React, { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { createBrowserClient } from '@supabase/ssr';
import { ArrowLeft, UploadCloud, FileText, CheckCircle, XCircle } from 'lucide-react';
import Papa from 'papaparse';

function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}

/**
 * Admin Import Page
 * - aceita CSV ou JSON para popular missions ou sos_tools
 * - pré-visualiza, valida, insere em lote (batch)
 * - usa supabase.from(...).insert([...]) com tamanho de lote configurável
 *
 * Colocar em: src/app/admin/import/page.tsx
 */

const BATCH_SIZE = 200; // número de registros por insert (ajustável)

export default function AdminImportPage() {
  const supabase = useMemo(() => createClient(), []);
  const [loading, setLoading] = useState(false);

  // UI states
  const [target, setTarget] = useState<'missions'|'sos_tools'>('missions');
  const [file, setFile] = useState<File | null>(null);
  const [rawText, setRawText] = useState('');
  const [preview, setPreview] = useState<any[]>([]);
  const [errors, setErrors] = useState<string[]>([]);
  const [successCount, setSuccessCount] = useState<number | null>(null);
  const [dryRun, setDryRun] = useState(true);

  useEffect(() => {
    setPreview([]);
    setErrors([]);
    setSuccessCount(null);
  }, [target]);

  function handleFileInput(f?: File) {
    setFile(f ?? null);
    setPreview([]);
    setErrors([]);
    setSuccessCount(null);
    setRawText('');
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => {
      const text = String(reader.result ?? '');
      setRawText(text);
      parseContent(text, f.name);
    };
    reader.onerror = (e) => {
      setErrors([`Erro lendo arquivo: ${String(e)}`]);
    };
    reader.readAsText(f);
  }

  function parseContent(text: string, filename = '') {
    setErrors([]);
    setPreview([]);
    // detect JSON?
    const trimmed = text.trim();
    if (trimmed.startsWith('[') || trimmed.startsWith('{')) {
      try {
        const parsed = JSON.parse(trimmed);
        if (!Array.isArray(parsed)) {
          setErrors(['JSON deve ser um array de objetos']);
          return;
        }
        const mapped = parsed.map(normalizeRow);
        setPreview(mapped);
        return;
      } catch (err:any) {
        setErrors([`Erro JSON: ${err.message ?? String(err)}`]);
        return;
      }
    }

    // otherwise try CSV with PapaParse
    const parsed = Papa.parse(text, { header: true, skipEmptyLines: true });
    if (parsed.errors && parsed.errors.length) {
      setErrors(parsed.errors.map((e:any) => `CSV parse error: ${e.message}`));
      // still try to use data if exists
    }
    const data = parsed.data as any[];
    const mapped = data.map(normalizeRow);
    setPreview(mapped);
  }

  // normaliza chaves e tipos por target
  function normalizeRow(raw: any) {
    // copy all keys lowercased trimmed
    const norm:any = {};
    for (const k of Object.keys(raw)) {
      const nk = String(k).trim();
      // unify headers like reward_xp or rewardXp -> reward_xp
      const key = nk.replace(/\s+/g, '_').replace(/[A-Z]/g, (m) => '_' + m.toLowerCase()).toLowerCase();
      norm[key] = raw[k];
    }

    if (target === 'missions') {
      // expected fields: title, description, category, difficulty, reward_xp, reward_coins, premium_only
      return {
        title: String(norm.title ?? '').trim(),
        description: norm.description ?? null,
        category: norm.category ?? null,
        difficulty: norm.difficulty ?? null,
        reward_xp: norm.reward_xp ? Number(norm.reward_xp) : 0,
        reward_coins: norm.reward_coins ? Number(norm.reward_coins) : 0,
        premium_only: (String(norm.premium_only ?? '').toLowerCase() === 'true') || norm.premium_only === true || norm.premium_only === '1',
      };
    } else {
      // sos_tools expected: title, description, steps (json string or pipe separated), type, category, duration_minutes, audio_url, premium_only
      let steps = norm.steps ?? norm.steps_json ?? null;
      if (steps && typeof steps === 'string') {
        // try parse JSON
        const s = steps.trim();
        if (s.startsWith('[')) {
          try { steps = JSON.parse(s); } catch { /* keep string as fallback */ }
        } else if (s.indexOf('|') !== -1) {
          steps = s.split('|').map((x:string) => x.trim());
        }
      }
      return {
        title: String(norm.title ?? '').trim(),
        description: norm.description ?? null,
        steps: steps ? (Array.isArray(steps) ? steps : [String(steps)]) : null,
        type: norm.type ?? null,
        category: norm.category ?? null,
        duration_minutes: norm.duration_minutes ? Number(norm.duration_minutes) : null,
        audio_url: norm.audio_url ?? null,
        premium_only: (String(norm.premium_only ?? '').toLowerCase() === 'true') || norm.premium_only === true || norm.premium_only === '1',
      };
    }
  }

  // validate preview rows
  function validatePreview(): string[] {
    const errs: string[] = [];
    if (!preview || preview.length === 0) {
      errs.push('Nenhum registro detectado para importar.');
      return errs;
    }
    preview.forEach((r, i) => {
      if (!r.title || String(r.title).trim().length === 0) errs.push(`Linha ${i+1}: title ausente.`);
      if (target === 'missions') {
        if (r.reward_xp != null && Number.isNaN(Number(r.reward_xp))) errs.push(`Linha ${i+1}: reward_xp inválido.`);
        if (r.reward_coins != null && Number.isNaN(Number(r.reward_coins))) errs.push(`Linha ${i+1}: reward_coins inválido.`);
      } else {
        if (r.duration_minutes != null && Number.isNaN(Number(r.duration_minutes))) errs.push(`Linha ${i+1}: duration_minutes inválido.`);
      }
    });
    return errs;
  }

  async function handleImport() {
    setErrors([]);
    setSuccessCount(null);

    const v = validatePreview();
    if (v.length) {
      setErrors(v);
      return;
    }
    if (dryRun) {
      setSuccessCount(preview.length);
      alert(`Dry-run: ${preview.length} registros válidos. Desmarque "Dry run" para inserir de fato.`);
      return;
    }

    // batch insert for stability
    setLoading(true);
    try {
      const rows = preview.slice(); // copy
      let inserted = 0;
      for (let i = 0; i < rows.length; i += BATCH_SIZE) {
        const chunk = rows.slice(i, i + BATCH_SIZE);
        // ensure fields: for missions we insert expected columns; for sos_tools cast steps -> jsonb
        if (target === 'missions') {
          const payload = chunk.map((r:any) => ({
            title: r.title,
            description: r.description,
            category: r.category,
            difficulty: r.difficulty,
            reward_xp: Number(r.reward_xp ?? 0),
            reward_coins: Number(r.reward_coins ?? 0),
            premium_only: !!r.premium_only,
          }));
          const { error } = await supabase.from('missions').insert(payload);
          if (error) throw error;
          inserted += payload.length;
        } else {
          const payload = chunk.map((r:any) => ({
            title: r.title,
            description: r.description,
            steps: r.steps ? r.steps : null,
            type: r.type,
            category: r.category,
            duration_minutes: r.duration_minutes ? Number(r.duration_minutes) : null,
            audio_url: r.audio_url ?? null,
            premium_only: !!r.premium_only,
          }));
          const { error } = await supabase.from('sos_tools').insert(payload);
          if (error) throw error;
          inserted += payload.length;
        }
      }

      setSuccessCount(inserted);
      alert(`Importação completa: ${inserted} registros inseridos em ${target}.`);
      // refresh admin lists optionally
    } catch (err:any) {
      console.error('Erro insert', err);
      setErrors([`Erro ao inserir: ${err.message ?? String(err)}`]);
    } finally {
      setLoading(false);
    }
  }

  function clearAll() {
    setFile(null); setRawText(''); setPreview([]); setErrors([]); setSuccessCount(null);
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 p-6">
      <header className="max-w-5xl mx-auto">
        <div className="bg-white p-4 rounded-2xl shadow flex items-center gap-3">
          <Link href="/admin" className="p-2 rounded hover:bg-gray-100"><ArrowLeft /></Link>
          <h1 className="text-xl font-bold">Importador Admin (CSV / JSON)</h1>
        </div>
      </header>

      <main className="max-w-5xl mx-auto mt-6 space-y-4">
        <section className="bg-white p-4 rounded-2xl shadow">
          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2">
              <input type="radio" checked={target==='missions'} onChange={()=>setTarget('missions')} />
              <span className="text-sm">Missions</span>
            </label>
            <label className="flex items-center gap-2">
              <input type="radio" checked={target==='sos_tools'} onChange={()=>setTarget('sos_tools')} />
              <span className="text-sm">SOS Tools</span>
            </label>

            <div className="ml-auto flex items-center gap-3">
              <label className="flex items-center gap-2 text-sm">
                <input type="checkbox" checked={dryRun} onChange={(e)=>setDryRun(e.target.checked)} />
                Dry run (não insere, apenas valida)
              </label>
              <div className="text-xs text-gray-500">Batch size: {BATCH_SIZE}</div>
            </div>
          </div>

          <div className="mt-4">
            <div className="flex items-center gap-3">
              <label className="inline-flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg cursor-pointer">
                <UploadCloud className="mr-2" /> Selecionar arquivo CSV/JSON
                <input type="file" accept=".csv,.json,text/csv,application/json" className="hidden" onChange={(e)=>handleFileInput(e.target.files ? e.target.files[0] : undefined)} />
              </label>

              <button className="px-3 py-2 border rounded" onClick={()=>{ if (file) handleFileInput(file); else alert('Selecione um arquivo primeiro'); }}>
                Parse / Previsualizar
              </button>

              <button className="px-3 py-2 border rounded" onClick={()=>clearAll()}>
                Limpar
              </button>
            </div>

            <div className="mt-3 text-sm text-gray-600">
              {file ? <div>Arquivo: <strong>{file.name}</strong> • Tamanho: {(file.size/1024).toFixed(1)} KB</div> : <div>Nenhum arquivo selecionado.</div>}
            </div>
          </div>
        </section>

        <section className="bg-white p-4 rounded-2xl shadow">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">Preview & Validação</h3>
            <div className="text-sm text-gray-500">{preview.length} registros</div>
          </div>

          <div className="mt-3">
            {errors.length > 0 && (
              <div className="bg-red-50 border border-red-100 p-3 rounded">
                <div className="flex items-center gap-2 text-red-700 font-semibold"><XCircle /> Erros</div>
                <ul className="mt-2 text-sm text-red-600 space-y-1">
                  {errors.map((e,i) => <li key={i}>{e}</li>)}
                </ul>
              </div>
            )}

            {successCount != null && (
              <div className="bg-green-50 border border-green-100 p-3 rounded">
                <div className="flex items-center gap-2 text-green-700 font-semibold"><CheckCircle /> Resultado</div>
                <div className="mt-2 text-sm text-green-700">{successCount} registros preparados{dryRun ? ' (dry-run)' : ''}.</div>
              </div>
            )}

            <div className="mt-4 max-h-[44vh] overflow-auto border rounded p-2">
              {preview.length === 0 && <div className="text-sm text-gray-500">Nenhum preview disponível — carregue e parse um CSV/JSON.</div>}
              {preview.length > 0 && (
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-left text-xs text-gray-500">
                      <th className="p-2">#</th>
                      <th className="p-2">Title</th>
                      <th className="p-2">Extra</th>
                    </tr>
                  </thead>
                  <tbody>
                    {preview.slice(0,500).map((r:any, idx:number) => (
                      <tr key={idx} className="border-t">
                        <td className="p-2 align-top">{idx+1}</td>
                        <td className="p-2 align-top"><strong>{r.title}</strong><div className="text-xs text-gray-500">{r.category ?? ''} {r.difficulty ?? ''}</div></td>
                        <td className="p-2 align-top">{target==='missions' ? `XP:${r.reward_xp} • Coins:${r.reward_coins} • premium:${r.premium_only}` : `Type:${r.type} • dur:${r.duration_minutes} • premium:${r.premium_only}`}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>

          <div className="mt-4 flex items-center gap-3">
            <button disabled={loading || preview.length===0} onClick={handleImport} className={`px-4 py-2 rounded-lg text-white ${dryRun ? 'bg-yellow-600' : 'bg-purple-600'}`}>
              {dryRun ? 'Executar Dry Run' : (loading ? 'Importando...' : 'Inserir no banco')}
            </button>

            <button onClick={()=>{ setPreview(prev => prev.slice(0,0)); setSuccessCount(null); setErrors([]); }} className="px-3 py-2 border rounded">Remover preview</button>
          </div>
        </section>

        <section className="bg-white p-4 rounded-2xl shadow text-sm text-gray-600">
          <h4 className="font-semibold">Notes & dicas</h4>
          <ul className="list-disc list-inside mt-2 space-y-1">
            <li>CSV deve ter cabeçalho; colunas opcionais serão preenchidas com valores padrão.</li>
            <li>Para steps no sos_tools você pode usar JSON na célula ou separar por pipe: "Passo 1|Passo 2".</li>
            <li>Dry run apenas valida. Tire o checkbox para inserir realmente.</li>
            <li>Se quiser importações muito grandes (milhares), prefira dividir em arquivos ou aumentar BATCH_SIZE e monitorar uso.</li>
          </ul>
        </section>
      </main>
    </div>
  );
}
